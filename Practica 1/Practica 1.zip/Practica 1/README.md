# Prácticas TIC

AUTORES:
- Gema Correa Fernandez
- Samuel Cardenete Rodríguez
- Pablo Parra Garófano


## Práctica 1

### Sesión 2:

- Apartado 4.3 - Ejercicio 9: arduLEDcontrol.cpp, arduLEDcontrol.cpp
- Apartado 4.3 - Ejercicio 10: arduLEDcontrol10.cpp, arduLEDcontrol10.cpp

### Sesión 3:

- Apartado 5.2  Ejercicio 5: fotoPC.cpp, fotoArdu.cpp

### Sesión 4-5:

- Apartado 6.2: arducodif.cpp
- Apartado 6.3: emisorPCS5.cpp, receptorPCS5.cpp, emisorArduS5.cpp, receptorArduS5.cpp
